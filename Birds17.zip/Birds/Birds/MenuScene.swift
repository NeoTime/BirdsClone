//
//  MenuScene.swift
//  Birds
//
//  Created by Johannes Ruof on 28.10.17.
//  Copyright © 2017 RUME Academy. All rights reserved.
//

import SpriteKit

class MenuScene: SKScene {
    
    var sceneManagerDelegate: SceneManagerDelegate?

}
